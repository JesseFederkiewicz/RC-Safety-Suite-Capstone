// WirelessMotors.h

#ifndef _WIRELESSMOTORS_h
#define _WIRELESSMOTORS_h

typedef enum MotorDirection {
	Forward = 0,
	Reverse = 1
};

void Main();

#endif

